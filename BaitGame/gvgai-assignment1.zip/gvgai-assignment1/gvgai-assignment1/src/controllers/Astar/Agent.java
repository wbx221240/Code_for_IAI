package controllers.Astar;

import core.game.Observation;
import core.game.StateObservation;
import ontology.Types;
import tools.ElapsedCpuTimer;
import tools.Vector2d;

import java.awt.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.PriorityQueue;

public class Agent extends controllers.sampleRandom.Agent{
    private class Node implements Comparable<Node>
    {

        @Override
        public int compareTo(Node o) {
            return Double.compare(this.F, o.F);
        }
        public double G;//to store the previous cost
        public double H;//to store the future cost
        public double F;//to store the predicted cost
        public StateObservation nodeCopy;//to store the current node information
        public LinkedList<Types.ACTIONS> preActions=null;//to store the parent actions
        public LinkedList<StateObservation> preStates=null;//to store the parent states
        //public StateObservation parent_state=null;
        public boolean key=false;
        public Vector2d avatarPosition;

        /**
         *
         * @param action_ the parent actions
         * @param state_ the parent states
         */
        public Node(LinkedList<Types.ACTIONS> action_, LinkedList<StateObservation> state_)
        {
            if(state_!=null)
            {
                nodeCopy= state_.getLast().copy();
            }

            preActions=action_;
            preStates=state_;
            //System.out.println("preStates size is:   "+preStates.size());
            //parent_state=state_.getLast().copy();
            if(state_==null)
            {
                key=false;
            }
            else {
                key=KEY();
            }
            avatarPosition=nodeCopy.copy().getAvatarPosition();
            //System.out.println("avatarPosition is:  "+avatarPosition);
        }
        public void init_node(double g)
        {
            G=g;
            H=heuristic();
            F=G+H;

        }
        public double heuristic()
        {
            if(key)
            {
                return Math.abs(avatarPosition.x-goalPosition.x)+Math.abs(avatarPosition.y-goalPosition.y)
                        +box_and_hole()+preStates.getLast().copy().getGameScore();
            }
            else {
                return Math.abs(avatarPosition.x-keyPosition.x)+Math.abs(avatarPosition.y-keyPosition.y)
                        +Math.abs(keyPosition.x-goalPosition.x)+Math.abs(keyPosition.y-goalPosition.y)
                        +box_and_hole()+preStates.getLast().copy().getGameScore();
            }
        }
        public double box_and_hole()
        {
            double cost=0;
            ArrayList<Observation>[] fixedPositions = nodeCopy.copy().getImmovablePositions();
            ArrayList<Observation>[] movingPositions = nodeCopy.copy().getMovablePositions();
            ArrayList<Observation> holes=null;
            ArrayList<Observation> boxes=null;
            if(fixedPositions.length>2)
            {
                holes=fixedPositions[fixedPositions.length-2];
            }
            if(movingPositions.length>1)
            {
                boxes=movingPositions[movingPositions.length-1];
            }
            if(holes!=null&&boxes!=null)
            {
                for(Observation hole:holes)
                {
                    for(Observation box:boxes)
                    {
                        cost+=Math.abs(hole.position.x-box.position.x)+Math.abs(hole.position.y-box.position.y);
                    }
                }
            }
            return cost;
        }
        public boolean KEY()
        {
            for(StateObservation state:this.preStates)
            {
                Vector2d avatarPosition=state.copy().getAvatarPosition();
                if(avatarPosition.x==keyPosition.x&&avatarPosition.y==keyPosition.y) {
                    return true;
                }
            }
            return false;
        }

    }/**
     * Public constructor with state observation and time due.
     *
     * @param so           state observation of the current game.
     * @param elapsedTimer Timer for the controller creation.
     */

    public Agent(StateObservation so, ElapsedCpuTimer elapsedTimer) {
        super(so, elapsedTimer);
    }
    private double heuristic_min_distance=1000000;//set a maximum for comparision.
    private LinkedList<StateObservation> searchedstates=null;
    private LinkedList<Types.ACTIONS> searchedactions=new LinkedList<>();

    private boolean key=false;//use it to make judgement whether avatar get the key as this relate to the distance.
    public Vector2d keyPosition;
    public Vector2d goalPosition;
    private PriorityQueue<Node> Open;
    private ArrayList<Node> Close=new ArrayList<>();
    private ArrayList<Node> Exist=new ArrayList<>();
    public int times=0;
    public boolean is_exist(Node n)
    {
        for(Node node:Exist)
        {
            if(node.nodeCopy.copy().equalPosition(n.nodeCopy.copy()))
            {
                return true;
            }
        }
        return false;
    }

    public Types.ACTIONS act(StateObservation stateObs, ElapsedCpuTimer elapsedTimer) {

        // read map information
        ArrayList<Observation>[] npcPositions = stateObs.getNPCPositions();
        ArrayList<Observation>[] fixedPositions = stateObs.getImmovablePositions();
        ArrayList<Observation>[] movingPositions = stateObs.getMovablePositions();
        ArrayList<Observation>[] resourcesPositions = stateObs.getResourcesPositions();
        ArrayList<Observation>[] portalPositions = stateObs.getPortalsPositions();
        grid = stateObs.getObservationGrid();

        printDebug(npcPositions, "npc");
        printDebug(fixedPositions, "fix");
        printDebug(movingPositions, "mov");
        printDebug(resourcesPositions, "res");
        printDebug(portalPositions, "por");
        System.out.println();

        Types.ACTIONS action = null;
        StateObservation stCopy = stateObs.copy();
        if(searchedstates==null)
        {
            searchedstates=new LinkedList<>();
        }

        //searchedactions=new LinkedList<>();
        goalPosition=fixedPositions[1].get(0).position;
        searchedstates.addLast(stateObs.copy());
        if(goalPosition==null)
        {
            goalPosition=fixedPositions[1].get(1).position;
        }
        if(!key)
        {
            keyPosition=movingPositions[0].get(0).position;
        }

        if(Open==null)
        {
            Open=new PriorityQueue<>();
            Node start=new Node(null,searchedstates);
            start.init_node(0);
            Open.add(start);
            Exist.add(start);
            times=0;//when establish a new searching, we need to update the time we do act.
        }
        LinkedList<Types.ACTIONS> actionslist=null;
        System.out.println();
        System.out.println("######################################");
        actionslist=ASTAR(times);
        //searchedactions.addLast(actionslist.get(times));//times));//add the second last action to the current searchedaction list.
        //heuristic_min_distance=1000000;//reset the heuristic_min_distance as we need to do LDS every step.
        //times++;//update the time as our next action to do is the times++^th.
        action=actionslist.get(times);
        System.out.println("ACTION!!");
        System.out.println("The returned action is :"+action);
        return action;
    }
    private boolean check_state(StateObservation stCopy, Node parent)
    {
        for(StateObservation obs:parent.preStates)
        {
            if(stCopy.copy().equalPosition(obs.copy()))
            {
                return true;
            }
        }
        return false;
    }
    private Node Find_node(Node n)
    {
        for(Node node:Exist)
        {
            if(n.nodeCopy.copy().equalPosition(node.nodeCopy.copy()))
            {
                return node;
            }
        }
        return null;
    }
    private boolean check_node(StateObservation obs)
    {
        for(Node node_: Exist)
        {
            if(node_.nodeCopy.copy().equalPosition(obs.copy()))
            {
                return true;

            }
        }
        return false;

    }
    private LinkedList<Types.ACTIONS> ASTAR(int time){

        LinkedList<Types.ACTIONS> actionsback=new LinkedList<>();
        while(!Open.isEmpty())
        {
            time++;
           Node current_node= Open.poll();
           Close.add(current_node);
           ArrayList<Types.ACTIONS> action_to_do =stCopy.getAvailableActions();
           if(current_node.nodeCopy.copy().getGameWinner()==Types.WINNER.PLAYER_WINS)
           {
               break;
           }
           for(Types.ACTIONS action:action_to_do)
           {
               StateObservation obs_next=current_node.nodeCopy.copy();
               obs_next.advance(action);
               

           }
        }
        /*
        //First, I need to poll the first element in the priority queue as current node.
        //then, if the current node don' t exist in the Exist array, then, we iterate the actions of it.
        //System.out.println("ASRAR");
        //System.out.println(Open.isEmpty());
        while(!Open.isEmpty())
        {
            Node current_node=Open.poll();
            Close.add(current_node);
            System.out.println("The current_position of the avatar is "+current_node.avatarPosition);
            //Exist.add(current_node);
            /*for(int i=0;i<current_node.preActions.size()-1;i++)
            {
                System.out.println(current_node.preActions.get(i));
            }
            System.out.println("The game has a winner?="+(current_node.nodeCopy.copy().getGameWinner()==Types.WINNER.PLAYER_WINS));
            if(current_node.nodeCopy.copy().getGameWinner()==Types.WINNER.PLAYER_WINS)
            {
                Open.add(current_node);
                Exist.add(current_node);
                return current_node.preActions;
            }
            ArrayList<Types.ACTIONS> action_done=current_node.nodeCopy.copy().getAvailableActions();
            System.out.println("Actions can be done:");
            for(Types.ACTIONS action:action_done)
            {
                System.out.println(action);
            }
            System.out.println("#####################       #######################");
            for(Types.ACTIONS action:action_done)
            {
                System.out.println(action);
                StateObservation obs_next= current_node.nodeCopy.copy();
                obs_next.advance(action);
                //System.out.println(is_exist(current_node));
                System.out.println("check state is  "+check_node(obs_next.copy()));
                System.out.println("game lose is  "+ (obs_next.copy().getGameWinner()==Types.WINNER.PLAYER_LOSES));
                if(check_node(obs_next.copy())||obs_next.copy().getGameWinner()==Types.WINNER.PLAYER_LOSES)
                {
                    continue;//if the node is already in the Exist list or we get a winner, we can stop from
                    // iterate the actions
                }
                Node temp=null;//temp is a possible element that may be appended to the Open Queue.
                LinkedList<Types.ACTIONS> pastActions=null;
                System.out.println("preActions is   "+(current_node.preActions==null));
                if(current_node.preActions==null)
                {
                    pastActions=new LinkedList<>();

                }
                else
                {
                    pastActions=(LinkedList<Types.ACTIONS>) current_node.preActions.clone();

                }
                pastActions.add(action);
                LinkedList<StateObservation> pastStates=(LinkedList<StateObservation>) current_node.preStates.clone();
                obs_next.copy().advance(action);
                pastStates.add(obs_next);
                temp=new Node(pastActions,pastStates);
                if(pastActions.size()>0)
                {
                    temp.init_node(pastActions.size()*50);
                }
                else if(pastActions.size()==0)
                {
                    temp.init_node(0);
                }
                if(is_exist(temp))
                {
                    Node same_node=Find_node(temp);
                    if(same_node.F<temp.F)
                    {
                       continue;
                    }


                }

                    Open.add(temp);
                    Exist.add(temp);
                    System.out.println("New Node adding successfully!");
                    System.out.println("##########  ############  ############");


            }
            System.out.println("#########################################");
        }*/
        return actionsback;
    }
    private void printDebug(ArrayList<Observation>[] positions, String str)
    {
        if(positions != null){
            System.out.print(str + ":" + positions.length + "(");
            for (int i = 0; i < positions.length; i++) {
                System.out.print(positions[i].size() + ",");

            }
            System.out.print("); ");
        }else System.out.print(str + ": 0; ");
    }

    /**
     * Gets the player the control to draw something on the screen.
     * It can be used for debug purposes.
     * @param g Graphics device to draw to.
     */
    public void draw(Graphics2D g)
    {
        int half_block = (int) (block_size*0.5);
        for(int j = 0; j < grid[0].length; ++j)
        {
            for(int i = 0; i < grid.length; ++i)
            {
                if(grid[i][j].size() > 0)
                {
                    Observation firstObs = grid[i][j].get(0); //grid[i][j].size()-1
                    //Three interesting options:
                    int print = firstObs.category; //firstObs.itype; //firstObs.obsID;
                    g.drawString(print + "", i*block_size+half_block,j*block_size+half_block);
                }
            }
        }
    }
}
